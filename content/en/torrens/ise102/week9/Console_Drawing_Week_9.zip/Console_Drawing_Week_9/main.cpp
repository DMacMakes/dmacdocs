#include <iostream>
#include <string>
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

void draw()
{
  //// WindowWidth and WindowHeight are both 30 by default.
  //// Draw a rectangle that fills the screen with colour to clear it
  //// From 0,0, and 30 total pixels wide and high.
  fillRect(0, 0, windowWidth(), windowHeight(), FG_DARK_MAGENTA);
  
  //// Here I do exactly the same thing with fillRectByCoords
  //// I draw from 0,0 to 29,29 because 0-29 is thirty (look at top border)
  fillRectByCoords(0, 0, windowWidth()-1, windowHeight()-1, FG_DARK_MAGENTA);

  //// Draw a rectangle 2 pixels shorter and narrower, starting at 1,1.
  //// That leaves us a 1 pixel border on all sides
  fillRect(1, 1, windowWidth()-2, windowHeight()-2, FG_GREY);
  
  //// Draw a single pixel mid screen
  drawPixel(windowWidth() / 2, windowHeight() / 2, FG_GREEN);
  
  //// Print the frames per second on the bottom visible row of the screen.
  drawString(1, windowHeight() - 1, "FPS: " + getFpsString(), layerColours(FG_GREY, BG_DARK_MAGENTA));
  
  //// Draw column numbers along the top row, leaving off the 1 in numbers > 9
  for (int x = 0; x < windowWidth(); x++) {
    drawWString(x, 0, to_wstring(x % 10), layerColours(FG_GREY, BG_DARK_MAGENTA));
  }
  //// draw = all along a row, but not on the borders.
  for (int x = 1; x < windowWidth()-1; x++) {
      drawWCharacter(x, 20, L'=', layerColours(FG_DARK_BLUE, BG_GREY));
  }
  return;

}

int main()
{
  bool playerHasQuit = false;
  //// Set up the console window for drawing text pixels. Default size is 30x30.
  textpixels::setupWindow();

  //// Main game loop
  do                        
  {
    textpixels::startFrame();   // Needed always at start of game loop
                                // Here we'd put input, processing
    draw();                     // output

    textpixels::endFrame();     // Needed always at end of game loop.
  } while (!playerHasQuit);     // Only stop when playerHasQuit
  
  //// Bye.
  return (0);
}