#include <iostream>
#include <string>
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

void draw()
{
  //// Draw a rectangle that fills the screen with colour to clear it
  fillRect(0, 0, windowWidth(), windowHeight(), FG_DARK_MAGENTA);
  
  //// Draw a smaller one inside it for easy borders.
  fillRect(1, 1, windowWidth()-1, windowHeight()-1, FG_GREY);
  
  //// Draw a single pixel mid screen
  drawPixel(windowWidth() / 2, windowHeight() / 2, FG_GREEN);
  
  //// Print the frames per second on the bottom visible row of the screen.
  drawString(1, windowHeight() - 1, "FPS: " + getFpsString(), layerColours(FG_GREY, BG_DARK_MAGENTA));
  
  //// Draw column numbers along the top row, leaving off the 1 in numbers > 9
  for (int column = 0; column < windowWidth(); column++) {
    drawWString(column, 0, to_wstring(column % 10), layerColours(FG_GREY, BG_DARK_MAGENTA));
  }
  //// draw = all along a row, but not on the borders.
  for (int column = 1; column < windowWidth()-1; column++) {
      drawWCharacter(column, 20, L'=', layerColours(FG_DARK_BLUE, BG_GREY));
  }
  return;
}

int main()
{
  bool playerHasQuit = false;
  //// Set up the console window for drawing text pixels. Default size is 30x30.
  textpixels::setupWindow();

  //// Main game loop
  do                        
  {
    textpixels::startFrame();   // Needed always at start of game loop
                                // Here we'd put input, processing
    draw();                     // output

    textpixels::endFrame();     // Needed always at end of game loop.
  } while (!playerHasQuit);     // Only stop when playerHasQuit
  
  //// Bye.
  return (0);
}