#include <iostream>
#include <string>
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

void draw()
{
  //// Draw a rectangle that fills the screen with a border colour
  //// draw a smaller rectangle in a screen background colour, leaving a 1 pixel border.
    
  return;
}

int main()
{
  bool playerHasQuit = false;
  
  //// Set up the console window for drawing text pixels. Default size is 30x30.
  textpixels::setupWindow();
  
  //// Main game loop
  do
  {
    textpixels::startFrame();   // Needed always at start of game loop
    
                                /// Input //////////
    // if key down is r or y, 
    // change background of screen
    if (keyIsDown('R'))         /// Storage ////////
    {
      // Do something so draw will 
      // know the background is now red
    }
                                /// Processing /////
                                
    draw();                     /// Output /////////
    
    textpixels::endFrame();     // Needed always at end of game loop.
  } while (!playerHasQuit);     // Only stop when playerHasQuit
  
  //// Bye.
  return (0);
}