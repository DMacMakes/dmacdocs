#ifndef __SNAKE__
#define __SNAKE__
#include "Point2d.h"
#include "textpixels_enums.h"

class Snake
{
public:

  short colour = 0x0;
  
  // Position and direction
  textpixels::Point2d location; //  = { 0,0 };
  textpixels::Direction xDir; // = Direction::NONE;
  textpixels::Direction yDir; // = Direction::NONE;
};

#endif

