#include <iostream>
#include <string>
#include "Snake.h"
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

enum Screen         // A collection of screens you would want in game
{
  MENU = 1,
  PLAY,
  PAUSE,
  GAMEOVER,
  EXIT,
  NONE
};

// The playing area, or game level, is above the graphic
// user interface, or GUI.
const int LEVEL_WIDTH = 35;
const int LEVEL_HEIGHT = 20;
const int GUI_HEIGHT = 10;

// Draw the Level's ground and border wall to top of window,
// draw gui with score and any other info at bottom.
void drawLevelAndGui();

// Display a menu featuring Play Snake and Exit
int displayMenuScreen();

// Plays a great game of hello game loop
// It would return their score.. if the game ever ended.
int playSnake();

int main()
{
  textpixels::setupWindow( LEVEL_WIDTH, LEVEL_HEIGHT+GUI_HEIGHT, 12, 15 );  // textpixels creates our 30x30 console window
  textpixels::setFps(10);    // Set high fps

  /// I chose `screen` as a term for part of the program with its own visuals+controls
  int screen = Screen::MENU;    // Start the game at the menu.
  int score = 0;

  /// Main game loop
  while (screen != Screen::EXIT)
  {
    if (screen == Screen::MENU)
    {
      screen = displayMenuScreen();
    }
    else if (screen == Screen::PLAY)
    {
      score = playSnake();
      screen = Screen::MENU;      /// When game is done, we want to go to menu.
    }
  }
  // Show Exit screen?
  return (0);
}

void drawLevelAndGui()
{
  // Draw the background and a wall.
  fillWindow(FG_GREY);
  fillRect(1, 1, LEVEL_WIDTH - 2, LEVEL_HEIGHT - 2, FG_DARK_MAGENTA);
  // Draw the gui background, starting at bottom of level
  fillRect(0, LEVEL_HEIGHT, LEVEL_WIDTH, GUI_HEIGHT, FG_BLACK);

  drawString(2, LEVEL_HEIGHT + 1, "(Q) ", FG_CYAN);
  drawString(6, LEVEL_HEIGHT + 1, "quit", FG_GREY);
}

int playSnake()
{
  int score = 0;
  // Initialise variables:
  bool playerHasQuit = false;
  // Create our snake. We'll call her slithers. She's Cyan.
  Snake slithers;              
  slithers.colour = FG_CYAN;
  // Set starting position 5 across, 10 down. 
  slithers.location.x = 5;
  // TODO: Set slithers y to 10
  slithers.xDir = Direction::RIGHT;
  // TODO: Set slithers y direction to none

  //// Main game loop
  do
  {
    textpixels::startFrame();   // Let textpixels know we're doing stuff in this frame.

    /////////////////////////////////////////// 1. CHECK INPUT
    if (keyIsDown('Q'))
    {
      playerHasQuit = true;
      break;  // End the loop now, we're done.
    }

    // Check if a, d, left/right arrow is pressed, store it 
    Direction xDirection = textpixels::getLeftRightInput();   
    //TODO: Do the same for yDirection (up down)

    /////////////////////////////////////////// 2. PROCESS GAME
    if (xDirection != Direction::NONE)
    {
      // Move our snake in the direction it is pointing
      // TODO: Set slithers' xDir to whatever is stored in xDirection.
      // TODO: Set slithers yDir to NONE, to avoid any diagonal movement.
    }
    // TODO: Do the same for yDirection
    // else if ()
    //{
    //  
    //}

    // 2. React to input (move characters, camera. Get pickup, take damage, 
    // increase gold, whatever). Move snake in whatever direction is set
    slithers.location.x += slithers.xDir; // xDir is -1, 0 or 1, so we can just add it to location x
    // TODO: Do the same for slithers yDirection.

    // TODO: Is y not working?? Can you fix the UP and DOWN 
    // directions in textpixels_enums.h?

    // 3. Draw things to the canvas (buffer)
    drawLevelAndGui();
    // Draw our snake the same way we drew any other pixel,
    // but giving drawPixel the location and colour info from slithers.
    // drawPixel(x, y, colour);  
    // TODO: Fix slithers so she has her correct y location and colour.
    drawPixel(slithers.location.x, 10);

    textpixels::endFrame();     // Tell textpixel it can draw the screen and sleep
  } while (!playerHasQuit);     // Only stop when playerHasQuit
  return score;
}

int displayMenuScreen()
{
  int choice = Screen::NONE;
  do                            // Keeps looping, waiting for input
  {
    textpixels::startFrame();   // Needed always at start of game loop
    fillWindow(FG_WHITE);
    drawString(8, 5, "(P) Play Snake", layerColours(FG_WHITE, BG_DARK_MAGENTA));
    drawString(8, 8, "(X) Exit", layerColours(FG_WHITE, BG_DARK_GREY));

    if (keyIsDown('P'))
    {
      choice = Screen::PLAY;
    }
    else if (keyIsDown('X'))
    {
      choice = Screen::EXIT;
    }
    textpixels::endFrame();     // Needed always at end of game loop.
  } while (choice == Screen::NONE);     // Only stop when playerHasQuit  
  return(choice);
}
