#include <iostream>
#include <string>
#include <Windows.h>
#include "textpixels_enums.h"
#include "textpixels.h"
#include "creature.h"
using namespace std;
using namespace textpixels;

enum Screen
{
  MENU = 1,
  PLAY,
  QUIT,
  NO_SCREEN
};

/// A global! 
int bestScore = 0;

/// Draw the background and border. The border has info 
/// including instructions and Frames per second)
void drawGameInterface()
{
  fillWindow(BG_BLACK);
  fillRect(1, 1, windowWidth() - 2, windowHeight() - 2, FG_DARK_YELLOW);
  drawString(2, 0, "Move around or (X) to exit", layerColours(FG_YELLOW, BG_BLACK));
  drawString(2, windowHeight() - 1, "FPS: " + getFpsString(), layerColours(FG_YELLOW, BG_BLACK));
}

/// Enter the game. Has its own loop which ends when the player hits (x)
void playFlappyBat()
{
  bool playerHasQuit = false;             
  _                   // batty the bat is a creature.
  _                   // Set her colour
  _                   // and starting position
  _
  
  /// Any screen taking input can have its own update loop.
  do
  {
    _                           // Needed always at start of game loop

    /// INPUT: checking for key presses
    _                       
    {
      // On directional input, set direction (-1, 0, 1) batty is heading.
      _                   // Moving in positive x
      _                   // Not moving in y (no diagonal movement)
    } _                           
    {
      _               
      _              
    }
    _                       
    {
      _                    
    }

    // PROCESSING: moving batty in her current x and y directions.
    _                     
    _                     
    
    // OUTPUT
    _                   
    _                                         
    _                           // Needed always at end of game loop.
  } while (!playerHasQuit);     // Only stop when playerHasQuit  
  
}

/// When it's all over, say goodbye
void showQuitScreen()
{
  _                        

  fillWindow(FG_DARK_BLUE);
  drawString(5, 5, "You did okay, not bat.", layerColours(FG_WHITE, BG_DARK_BLUE));

  _                       
  _               // Wait a beat before closing window. From Windows.h
}

int main()
{
  textpixels::setupWindow();
  textpixels::setFps(100);      // Set high fps
  
  /// No menu yet, so no loop here. Play screen has its own internal loop.
  playFlappyBat();    // Go to play screen

  showQuitScreen();
  return (0);
}