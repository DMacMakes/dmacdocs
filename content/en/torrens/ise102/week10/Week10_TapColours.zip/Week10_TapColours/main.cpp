#include <iostream>
#include <string>
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

void draw()
{
  ////  Fill screen with a chosen colour.
  return;
}

int main()
{
  bool playerHasQuit = false;
  
  //// Set up the console window for drawing text pixels. Default size is 30x30.
  textpixels::setupWindow();
  
  //// Main game loop
  do
  {
    textpixels::startFrame();   // Needed always at start of game loop
    
    /// Input //////////
    // if key down is r or y, fill screen with red or yellow
    if (keyIsDown('R'))         /// Storage ////////
    {
      // Call draw in a way that makes it draw a red background.
      
    }
    // Here, listen for a Y press and ask draw to fill the background with yellow.
                                
    draw();                     /// Output /////////
    
    textpixels::endFrame();     // Needed always at end of game loop.
  } while (!playerHasQuit);     // Only stop when playerHasQuit
  
  //// Bye.
  return (0);
}