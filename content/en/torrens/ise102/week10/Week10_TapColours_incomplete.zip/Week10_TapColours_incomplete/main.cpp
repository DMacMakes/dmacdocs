#include <iostream>
#include <string>
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

// Plays a great game of hello game loop
// It would return their score.. if the game ever ended.
int playScreenFiller()
{
    bool playerHasQuit = false;
    bool sayHello = true;
    //// Main game loop
    do
    {
        textpixels::startFrame();   // Let textpixels know we're doing stuff in this frame.

        // 1. Check input
        // if key down is r or y, remember that!
        sayHello = keyIsDown('H');  // testing keyIsDown, which returns true or false.
       
        // 2. Draw things to the canvas (buffer)
        // If r or y was down, fill the screen with red or yellow.
        // (Here's some testing code for drawing)
        fillWindow(FG_BLACK);   // Wipe the console by filling it with black.
        
        drawString(2, 4, "Hold down H to say Hello.");
        if (sayHello)
        {
          drawString(2, 6, "Hello game loop!", FG_MAGENTA);
        }

        textpixels::endFrame();     // Tell textpixel it can draw the screen and sleep

    } while (!playerHasQuit);     // Only stop when playerHasQuit
    return 1000;
}

int main()
{
    textpixels::setupWindow();  // textpixels creates our 30x30 console window

    int score = 0;
    score = playScreenFiller();     // Play one game, get score back.

    return (0);
}
