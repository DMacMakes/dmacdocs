#include <iostream>
#include <string>
#include <conio.h>
#include "termcolor.h"
using namespace std;
using namespace termcolor;

// Constants for home menu
enum HomeMenuChoice
{
  PLAY = 1,
  CREDITS = 2,
  QUIT = 3,
  NO_CHOICE
};

// All players start out with $2K
const int STARTING_MONEY = 2000;
const string ANYKEY_MSG_DEFAULT = "Press any key to return to the menu..";

void waitForAnyKey(string message = ANYKEY_MSG_DEFAULT)
{
  cout << "\t ----------------------------------------------\n";
  cout << "\t          " << message << "\n";
  cout << "\t ----------------------------------------------";
  _getch();                            // Pauses execution until keypress.
  system("cls");
}

// Displays player cash, menu. Gets valid choice from player
// Input: player cash total. Output: a valid hoice made by player
int showHomeMenuPrompt(int money)
{
  int choice = -1;
  
  // I use on_red to put the text on a red background, then termcolor::reset
  // to go back to whatever it was before (depends on command prompt setup)
  cout << "\t " << on_red << "----------------------------" << termcolor::reset << "\n";
  cout << "\t " << on_cyan << "        HOKIE POKIE         \n" << termcolor::reset;
  cout << "\t " << on_cyan << "       You have " << green << "$" << money << "       " << termcolor::reset << "\n";
  cout << "\t " << on_red << "----------------------------" << termcolor::reset << "\n\n";

  // Here i use `magenta` to change the foreground color, then go back to `white`.
  // To see all colours and functions of termcolour, type `termcolor::` and let 
  // autocomplete show you the options.
  cout << "\t\t  " << magenta << "1" << white << ": Play \n";
  cout << "\t\t  " << magenta << "2" << white << ": Credits \n";
  cout << "\t\t  " << magenta << "3" << white << ": Quit \n\n";
  cout << "\t     Enter your choice " << magenta << ">" << white << " ";

  cin >> choice;
  return choice;
}

// Manage whole slot playing cycle
// Input: player total cash. Output: cash total after playing
int playSlots(int moneyInserted)
{
  system("cls");
  cout << "\n\t Ready to play? You have " << green << "$" << moneyInserted << white << " available.\n\n";
  // currentMoney represents changing money throughout one round of slots.
  int winnings = 200;
  cout << "\t $$$  You won " << green << "$" << winnings << white << "  $$$\n\n";
  
  waitForAnyKey();
  return(moneyInserted + winnings);
}

int main()
{
  int choice = NO_CHOICE;
  int playerMoney = STARTING_MONEY;

  while (choice != QUIT)    // Add check: player isn't broke
  {
    choice = showHomeMenuPrompt(playerMoney);  // Offer starting menu
    if (choice == PLAY)
    {
      // Put current player money into the slot machine and play, 
      // update playerMoney after game is complete.
      playerMoney = playSlots(playerMoney);
    }
  }

  // Quit was chosen, ending While loop.

  system("cls");    // clear screen

  /// Use this trick to format ascii art.
  /// cout accepts the extra strings without `<<` joining them
  cout << "\n\t\t       You did okay. \n\n";
  cout << magenta << 
    "\t\t   _____________________\n" 
    "\t\t  |  _________________  |\n" 
    "\t\t  | |    10000000000. | |\n"
    "\t\t  | |_________________| |\n"
    "\t\t  |  ___ ___ ___   ___  |\n"
    "\t\t  | | 7 | 8 | 9 | | + | |\n"
    "\t\t  | |___|___|___| |__ | |\n"
    "\t\t  | | 4 | 5 | 6 | | - | |\n"
    "\t\t  | |___|___|___| |__ | |\n"
    "\t\t  | | 1 | 2 | 3 | | x | |\n"
    "\t\t  | |___|___|___| |__ | |\n"
    "\t\t  | | . | 0 | = | | / | |  \n"
    "\t\t  | |___|___|___| |___| |  \n"
    "\t\t  |_____________________|  \n\n"
    "\t\t        TRY HARDER.            \n\n" << termcolor::reset;

  return(0);
}