/*******************************************************
*
*  Academic Integrity Declaration (replace with Image)
*  I, Daniel McGillick declare that except where I have
*  referenced, the work I am are submitting in this attachment is my
*  own work. I acknowledge and agree that the assessor of this assignment
*  may, for the purpose of authenticating this assignment, reproduce it for the
*  purpose of detecting plagiarism. I have read and am aware of the
*  Think Education Policy and Procedure viewable online at
*  http://www.think.edu.au/studying-at-think/policies-and-procedures/
*
*****************************************************/

#include <iostream>
#include <string>
#include <vector>
#include "Snake.h"
#include "Fruit.h"
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

enum Screen         // A collection of screens you would want in game
{
  MENU = 1,
  PLAY,
  PAUSE,
  GAMEOVER,
  EXIT,
  NONE
};

// The playing area, or game level, is above the graphic
// user interface, or GUI.
const int LEVEL_WIDTH = 35;
const int LEVEL_HEIGHT = 16;
const int GUI_HEIGHT = 10;

// Draw the Level's ground and border wall to top of window,
// draw gui with score and any other info at bottom.
void drawLevelAndGui(int bananaCount);

// Display a menu featuring Play Snake and Exit
int displayMenuScreen();

// Plays a great game of Snake
// It would return their score.. if we implented scoring.
int playFruitLand();

int main()
{
  textpixels::setupWindow( LEVEL_WIDTH, LEVEL_HEIGHT+GUI_HEIGHT, 24, 24 );  // textpixels creates our 30x30 console window
  textpixels::setFps(200);    // Set high fps
  
  /// I chose `screen` as a term for part of the program with its own visuals+controls
  int screen = Screen::MENU;    // Start the game at the menu.
  int score = 0;

  /// Main game loop
  while (screen != Screen::EXIT)
  {
    if (screen == Screen::MENU)
    {
      screen = displayMenuScreen();
    }
    else if (screen == Screen::PLAY)
    {
      score = playFruitLand();
      screen = Screen::MENU;      /// When game is done, we want to go to menu.
    }
  }
  // Show Exit screen?
  return (0);
}

void drawLevelAndGui(int bananaCount)
{
  const int PLAY_ZONE_FG = FG_GREY;
  const int PLAY_ZONE_BG = BG_GREY;
  const int GUI_ZONE_FG = FG_BLACK;
  const int GUI_ZONE_BG = BG_BLACK;
  const int GUI_KEY_COL = layerColours(FG_CYAN, GUI_ZONE_BG);
  const int GUI_OPTION_COL = layerColours(FG_WHITE, GUI_ZONE_BG);

  // Draw the background and a wall.
  fillWindow(FG_CYAN);
  fillRect(1, 1, LEVEL_WIDTH - 2, LEVEL_HEIGHT - 2, PLAY_ZONE_FG);
  // Draw the gui background, starting at bottom of level
  fillRect(1, LEVEL_HEIGHT + 1, LEVEL_WIDTH - 2, GUI_HEIGHT - 2, GUI_ZONE_FG);

  // Write key options to the gui
  drawString(2, LEVEL_HEIGHT + 2, "Fruit Land!", GUI_KEY_COL);
  drawString(2, LEVEL_HEIGHT + 4, "Bananas:", GUI_KEY_COL);
  drawString(10, LEVEL_HEIGHT + 4, to_string(bananaCount), GUI_OPTION_COL);
}

int playFruitLand()
{
  bool playerHasQuit = false;
  
  Fruit grape;
  grape.colour = Colour::FG_MAGENTA;
  grape.location.x = 28;
  grape.location.y = 8;
  Fruit strawberry;
  strawberry.colour = Colour::FG_RED;
  strawberry.kind = "cherry";
  strawberry.location = Point2d(8,12);   // An easy 1 line way of initialilizing a Point2D

  //TODO: Declare a vector of Fruit, name it punnet
  //TODO: push the grape and the strawberry onto the end/back of it
  
  //TODO: Declare a vector of Fruit, call it bananas
  vector<Fruit> bananas;    // A bunch of bananas
  for (int i = 0; i < 10; i++)
  {
    // Each time through the loop, create a new banana.
    Fruit tempBanana;
    tempBanana.colour = FG_YELLOW;
    tempBanana.location = Point2d(i*2, 4);  // space out the bananas across a row
    //TODO: push banana into bananas vector
  }
  
  //// Main game loop
  do
  {
    textpixels::startFrame();   // Let textpixels know we're doing stuff in this frame.
    
    //TODO: Call drawLevelAndGui, pass it the size of the bananas vector

    // for each Fruit found in punnet, give it to me as a variable called "fruit"
    for (Fruit fruit : punnet)
    {
      drawPixel(fruit.location.x, fruit.location.y, fruit.colour);
    }
    //TODO: For every banana in bananas, draw it to the screen.
    
    textpixels::endFrame();     // Tell textpixel it can draw the screen and sleep
  } while (!playerHasQuit);     // Only stop when playerHasQuit
  return 100; // fake score
}

int displayMenuScreen()
{
  int choice = Screen::NONE;
  do                            // Keeps looping, waiting for input
  {
    textpixels::startFrame();   // Needed always at start of game loop
    fillWindow(FG_WHITE);
    drawString(8, 5, "(P) Play Fruit Land", layerColours(FG_WHITE, BG_DARK_MAGENTA));
    drawString(8, 8, "(X) Exit", layerColours(FG_WHITE, BG_DARK_GREY));

    if (keyIsDown('P'))
    {
      choice = Screen::PLAY;
    }
    else if (keyIsDown('X'))
    {
      choice = Screen::EXIT;
    }
    textpixels::endFrame();     // Needed always at end of game loop.
  } while (choice == Screen::NONE);     // Only stop when playerHasQuit  
  return(choice);
}
