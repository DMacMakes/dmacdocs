#ifndef __FRUIT__
#define __FRUIT__

#include <string>
#include "Point2d.h"
#include "textpixels_enums.h"

class Fruit
{
public:

  short colour = 0x0;
  int pointValue = 0;
  
  std::string kind = "";
  textpixels::Point2d location; //  = { 0,0 };
};

#endif

