#ifndef __FRUIT__
#define __FRUIT__

class Fruit
{
public:
  int x = 0;
  int y = 0;
  short colour = 0x0;
  string kind = "banana";
};

#endif