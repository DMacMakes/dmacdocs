#include <iostream>
#include <string>
#include <Windows.h>
#include "textpixels_enums.h"
#include "textpixels.h"
#include "creature.h"
#include "fruit.h"
using namespace std;
using namespace textpixels;

enum Screen         // A collection of screens you would want in game
{
  MENU = 1,
  PLAY,
  PAUSE,
  GAMEOVER,
  QUIT,
  NO_SCREEN
};

/// A global! 
int bestScore = 0;

int showMenu()
{
  int choice = NO_SCREEN;
  do                            // Keeps looping, waiting for input
  {
    textpixels::startFrame();   // Needed always at start of game loop
    fillWindow(FG_DARK_GREY);
    drawString(3, 5, "(P) Play Snake (Q) Quit", layerColours(FG_WHITE, BG_DARK_GREY));

    if (keyIsDown('P'))
    {
      choice = PLAY;
    }
    else if (keyIsDown('Q'))
    {
      choice = QUIT;
    }

    textpixels::endFrame();     // Needed always at end of game loop.
  } while (choice == NO_SCREEN);     // Only stop when playerHasQuit  
  return(choice);
}

/// Draw the background and border. The border has info 
/// including instructions and Frames per second)
void drawGameInterface(int currentScore)
{
  /// Fill window with border colour, then draw grass.
  fillWindow(FG_WHITE); 
  fillRect(1, 1, windowWidth() - 2, windowHeight() - 2, FG_DARK_GREEN);

  /// Draw info/instructions
  drawString(2, 0, "(X) to exit", layerColours(FG_BLACK, BG_WHITE));
  drawString(2, windowHeight() - 1, "FPS " + getFpsString(), layerColours(FG_BLACK, BG_WHITE));
  
  /// Here you should draw the score to the top right or bottom right of screen 
}

/// Enter the game. Has its own loop which ends when the player hits (x)
void playGame()
{
  int score = 0;
  int movingFrame = 8;        // We control speed by moving on every xth frame
  bool playerHasQuit = false;
  Creature batty;             
  batty.colour = FG_BLACK;    
  batty.x = 2;                
  batty.y = 15;
  Fruit banana;
  banana.x = banana.y = 20;   
  banana.colour = FG_YELLOW;

  /// Any screen taking input can have its own update loop.
  do
  {
    textpixels::startFrame();   

    /// INPUT: checking for key presses
    if (keyIsDown(VK_RIGHT))
    {
      // On directional input, set direction (-1, 0, 1) batty is heading.
      batty.xDir = 1;     // Moving in positive x
      batty.yDir = 0;     // Not moving in y (no diagonal movement)
    } else if (keyIsDown(VK_LEFT))
    {
      batty.xDir = -1;
      batty.yDir = 0;
    }
    else if (keyIsDown(VK_UP))
    {
      batty.xDir = 0;
      batty.yDir = -1;
    }
    else if (keyIsDown(VK_DOWN))
    {
      batty.xDir = 0;
      batty.yDir = 1;
    } 
    else if (keyIsDown('X'))
    {
      playerHasQuit = true;
    }

    // PROCESSING: moving batty in her current x and y directions.
    // Move after a certain number of frames elapses
    if (textpixels::frame() % movingFrame == 0)  
    {
      batty.x += batty.xDir;
      batty.y += batty.yDir;
      
      // teleport if she's out of bounds
      if (batty.x >= windowWidth() - 1)
      {
        batty.x = 1;
      }
      else if (batty.x <= 0) // else if batty x out of bounds low..
      {
        // change batty x to highest safe pixel
        batty.x = windowWidth() - 2;
      }
      else if (batty.y >= windowHeight() -1)
      {
        batty.y = 1;
      }
      else if (batty.y <= 0)
      {
        // change her y to greatest safe pixel
        batty.y = windowHeight()-2;
      }
      
      // if batty x and y match the fruit's x and y:
      if (batty.x == banana.x && batty.y == banana.y)
      {
        //  Increase player score
        //  Give the fruit a new location
        banana.x -= 2;
        banana.y -= 3;
      }
    }
    
    // OUTPUT
    drawGameInterface(score);

    // draw fruit and bat
    textpixels::drawPixel(banana.x, banana.y, banana.colour);
    textpixels::drawPixel(batty.x, batty.y, batty.colour);
    
    textpixels::endFrame();     // Needed always at end of game loop.
  } while (!playerHasQuit);     // Only stop when playerHasQuit  
  
}

/// When it's all over, say goodbye
void showQuitScreen()
{
  textpixels::startFrame();

  fillWindow(FG_DARK_RED);

  textpixels::endFrame();
  Sleep(1500);    // Wait a beat before closing window. From Windows.h
}

int main()
{
  textpixels::setupWindow(50,25);    // Defaults window to 30x30. Change if you like.
  textpixels::setFps(100);      // Set high fps
  
  /// I chose `screen` as a term for part of the program with its own visuals+controls
  int screen = MENU;
  /// Main game loop
  while (screen != QUIT)
  {
    if (screen == MENU)
    {
      screen = showMenu();
    }
    else if (screen == PLAY)
    {
      playGame();
      screen = MENU;      /// When game is done, we want to go to menu.
    }
  }

  /// If loop is over, screen was QUIT so..
  showQuitScreen();
  return (0);
}
