#ifndef __BAG__
#define __BAG__
#include <string>

class Bag
{
public:
  int x = 0;
  int y = 0;
  short colour = 0x0;
  string brand = "KMart";
};

#endif