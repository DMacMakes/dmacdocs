#include <iostream>
#include <string>
#include <vector>
#include "textpixels_enums.h"
#include "textpixels.h"
#include "fruit.h"
#include "bag.h"
using namespace std;
using namespace textpixels;


void showVectorTests()
{
  bool playerHasQuit = false;
  
  //..                // initialising with a set of values using { val, val, val.. }
  
  int fruitWanted = 6;
  //..

  int bagsStored = 80;
  //..

  /// Make some fruit, put them in scatteredFruit collection
  for(int i = 0; i < fruitWanted; i++)
  {
    //..
    fruit.x = i * 2 + 10;     // easy way to space out the fruit
    fruit.y = i * 2 + 10;     
    fruit.colour = FG_MAGENTA;
    //..
  }


  for (int i = 0; i < bagsStored; i++)
  {
    /// You can create a new bag with default values by calling Bag()
    /// Since it's an argument to vector::push_back() it'll be stored
    /// in our vector for accessing.
    //..
  }

  do
  {
    textpixels::startFrame();

    drawString(4, 3, "scores: ");
    //..
    //..
    //..
    
    //..for
    //..
    //..
    //..
    

    //..

    textpixels::endFrame();     // Needed always at end of game loop.
  } while (!playerHasQuit);     // Only stop when playerHasQuit  
  
}

int main()
{
  textpixels::setupWindow(50,25);    // Defaults window to 30x30. Change if you like.
  textpixels::setFps(100);      // Set high fps
  
  /// I chose `screen` as a term for part of the program with its own visuals+controls
  showVectorTests();
  
  return (0);
}
