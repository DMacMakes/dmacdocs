#ifndef __CREATURE__
#define __CREATURE__

class Creature
{
public:
  int x = 0;
  int y = 0;
  short colour = 0x0;
  
  int xDir = 0;
  int yDir = 0;
};

#endif

