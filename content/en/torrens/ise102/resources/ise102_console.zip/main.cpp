#include <iostream>
#include <string>
using namespace std;

int main()
{
  string message = "Hello Console.";

  cout << message << endl;

  return(0);
}