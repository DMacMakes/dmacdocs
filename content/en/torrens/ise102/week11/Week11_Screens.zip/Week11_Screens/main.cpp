#include <iostream>
#include <string>
#include <Windows.h>
#include "textpixels_enums.h"
#include "textpixels.h"

using namespace std;
using namespace textpixels;

enum Screen
{
  MENU = 1,
  PLAY,
  PAUSE,
  GAMEOVER,
  QUIT,
  NO_SCREEN
};

int bestScore = 0;

int showMenu()
{
  int choice = NO_SCREEN;
  do                            // Keeps looping, waiting for input
  {
    textpixels::startFrame();   // Needed always at start of game loop
    fillWindow(BG_DARK_GREY);
    drawString(3, 5, "(P) Play Snake (Q) Quit", layerColours(FG_WHITE, BG_DARK_BLUE));

    if (keyIsDown('P'))
    {
      choice = PLAY;
    }
    else if (keyIsDown('Q'))
    {
      choice = QUIT;
    }
    
    textpixels::endFrame();     // Needed always at end of game loop.
  } while (choice==NO_SCREEN);     // Only stop when playerHasQuit  
  return(choice);
}

void showQuitScreen()
{
  textpixels::startFrame();   // Needed always at start of game loop
  
  fillWindow(FG_DARK_BLUE);
  drawString(3, 5, "Later skater.", layerColours(FG_WHITE, BG_DARK_BLUE));
  textpixels::endFrame();     // Needed always at end of game loop.
  Sleep(1500);
}

int playSnake()
{
  int score = 0;
  bool playAgain = true;
  int screen = PLAY;
  
  /// We can easily choose, inside the Snake game, to display
  /// the snake and world, or to display a simpler screen like "Game Over"
  // You could even do it as a popup
  do
  {
    textpixels::startFrame();   // Needed always at start of game loop

    if (screen == PLAY)         // Draw the regular snake world here
    {
      if (keyIsDown('G'))       // Allow for quitting 
      {
        screen = GAMEOVER;
      }
      // Listen for other keypresses
      // Move the snake, eatc fuit, score points etc
      fillWindow(BG_DARK_GREEN);
      drawString(3, 5, "ssssssssO~", layerColours(FG_WHITE, BG_DARK_GREEN));
      drawString(3, 7, "(G) to Give Up ", layerColours(FG_WHITE, BG_DARK_BLUE));
      drawString(2, windowHeight() - 1, "FPS: " + getFpsString());
      // Draw the Snake, fruit etc.
      
    }
    else if (screen == GAMEOVER)  // Display overlay, allowing to play again or go to menu.
    {
      fillWindow(BG_DARK_RED);
      drawString(3, 5, "Game Over. Score: X", layerColours(FG_WHITE, BG_DARK_RED));
      drawString(3, 7, "(P) Play (Esc) Menu", layerColours(FG_WHITE, BG_DARK_BLUE));
      if (keyIsDown('P'))
      {
        // reset variables for new game.
        screen = PLAY;
      }
      else if (keyIsDown(VK_ESCAPE))
      {
        playAgain = false;
      }
    }

    textpixels::endFrame();     // Needed always at end of game loop.
  } while (playAgain);     // Only stop when playerHasQuit  
  return(score);            // 
}

int main()
{
  //// Set up the console window for drawing text pixels. Default size is 30x30.
  textpixels::setupWindow();
  textpixels::setFps(100);
  int screen = MENU;
  //// Main game loop

  while (screen != QUIT)
  {
    switch (screen)
    {
    case MENU:
      screen = showMenu();
      break;
    case PLAY:
      /// Play Snake, get back a score. Store if new high score.
      playSnake();
      screen = MENU;
      break;
    }
  }
  showQuitScreen();
  
  return (0);
}
