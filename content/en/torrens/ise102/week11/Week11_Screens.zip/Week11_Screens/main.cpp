#include <iostream>
#include <string>
#include <Windows.h>
#include "textpixels_enums.h"
#include "textpixels.h"
using namespace std;
using namespace textpixels;

enum Screen { MENU = 1,  PLAY,  QUIT,  NO_SCREEN };
int bestScore = 0;

void showQuitScreen()
{
  textpixels::startFrame();   // Needed always at start of game loop
  fillWindow(FG_DARK_BLUE);
  drawString(3, 5, "Later skater.", layerColours(FG_WHITE, BG_DARK_BLUE));
  textpixels::endFrame();     // Needed always at end of game loop.
  Sleep(1500);
}

int showMenu()
{
  int choice = NO_SCREEN;
  do                            // Keeps looping, waiting for input
  {
    textpixels::startFrame();   // Needed always at start of game loop
    fillWindow(BG_DARK_GREY);
    drawString(3, 5, "(P) Play Snake (Q) Quit", layerColours(FG_WHITE, BG_DARK_BLUE));
    
    if (keyIsDown('P'))
    {
      choice = PLAY;
    }
    else if (keyIsDown('Q'))
    {
      choice = QUIT;
    }
    textpixels::endFrame();     // Needed always at end of game loop.
  } while (choice==NO_SCREEN);     // Only stop when playerHasQuit  
  return(choice);
}

int playSnake()
{
  int score = 0;
  bool playerHasQuit = false;
  
  do
  {
    textpixels::startFrame();   // Needed always at start of game loop

    if (keyIsDown('X')) playerHasQuit = true;    // Single line if statement
    fillWindow(BG_DARK_GREEN);
    drawString(3, 0, "(X) to Exit", layerColours(FG_WHITE, BG_BLACK));
    drawPixel(10, 15, FG_GREEN);              // Snake

    textpixels::endFrame();  
  } while (!playerHasQuit);     // Only stop when playerHasQuit  
  return(score);            // 
}

int main()
{
  //// Set up the console window for drawing text pixels. Default size is 30x30.
  textpixels::setupWindow();
  textpixels::setFps(100);
  int screen = MENU;         // Set `screen` to the screen you want to see next
 
  // This loop is controlled by choices made in `showMenu()`
  while (screen != QUIT)
  {
    if (screen == MENU)
    {
      // Show the menu, and store the user's choice in the `screen` variable
      screen = showMenu();
    }
    else if (screen == PLAY)
    {
      /// Play Snake, get back a score. Store if new high score.
      playSnake();
      // When playSnake has finished, we want to go back to the menu, so:
      screen = MENU;
    }
  }
  // They must have picked quit, causing the loop to end
  showQuitScreen();
  return (0);
}
